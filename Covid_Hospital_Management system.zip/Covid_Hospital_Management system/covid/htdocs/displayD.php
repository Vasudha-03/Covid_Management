<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Profile</title>
    <style type="text/css">
        body {
            display: flex;
            flex-direction: column;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .con {
            display: block;
            align-items: left;
            height: 9%;
            width: 100%;
            justify-content: center;
            background-color: #14076F;
        }

        .logo {
            height: 60px;
            width: auto;
            margin-left: 20px;
        }

        .pic {
            margin-top: 10px;
            height: 30px;
            width: 50px;
            float: right;
            margin-right: 20px;
        }

        .container {
            text-align: center;
            margin-top: 20px;
        }

        .card {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 20px;
        }

        .card-item {
            background: #fff;
            border: 2px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            width: 300px;
            max-height: 100%;
        }

        a {
            text-decoration: none;
            color: white;
        }

        button {
            width: 80px;
            height: 30px;
            background: #14076F;
            border: none;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
            transition: .4s ease;
            color: #fff;
            text-decoration: none;
        }

        button:hover {
            background: #5B4FB3;
        }
    </style>
</head>

<body>
    <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <a href="Home.php"><img class="pic" src="menu.png"></a>
        </nav>
    </div>

    <div class="container">
        <h2>Doctor Profile</h2>
    </div>

    <div class="card">
        <?php
        $sql = "SELECT * FROM doctor_login";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result(); /*result will be stored return the result query*/

        while ($row = $result->fetch_assoc()) {
        ?>
            <div class="card-item">
                <p><strong>Name:</strong> <?php echo $row['NAME']; ?></p>
                <p><strong>Qualification:</strong> <?php echo $row['QUALIFICATION']; ?></p>
                <p><strong>Experience:</strong> <?php echo $row['EXPERIENCE']; ?></p>
                <p><strong>Gender:</strong> <?php echo $row['GENDER']; ?></p>
                <p><strong>Age:</strong> <?php echo $row['AGE']; ?></p>
                <p><strong>Phone:</strong> <?php echo $row['PHONE']; ?></p>
                <p><strong>ID:</strong> <?php echo $row['ID']; ?></p>
                <p><strong>Password:</strong> <?php echo $row['PASSWORD']; ?></p>
                <p><strong>Confirm Password:</strong> <?php echo $row['CONFIRMPASSWORD']; ?></p>
                <button><a href="doctorupdate.php?NAME=<?php echo $row['NAME']; ?>">UPDATE</a></button>
                <button>
                <a href="delete_doctor.php?id=<?php echo $row['ID']; ?>" onclick="return confirm('Are you sure you want to delete this profile?')">DELETE</a>
                </button>
            </div>
        <?php
        }
        ?>
    </div>

</body>

</html>
