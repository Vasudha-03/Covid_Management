<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    $appointment_id = $_POST['appointment_id'];
    $appointment_type = $_POST['appointment_type'];
    $action = $_POST['action'];

    // Define status based on action
    $status = ($action === 'accept') ? 'accepted' : 'rejected';

    // Update appointment status in the database based on appointment type
    switch ($appointment_type) {
        case 'test':
            $table = 'test';
            break;
        case 'vaccine':
            $table = 'vaccine';
            break;
        case 'consult':
            $table = 'consult';
            break;
        default:
            // Handle unknown appointment type
            break;
    }

    if (isset($table)) {
        $sql = "UPDATE $table SET status = ? WHERE ADHAR = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $status, $appointment_id);
        $stmt->execute();

        // Optionally, you can echo a response to indicate success or failure
        $welcome_message ="Appointment status updated successfully";

        $stmt->close();
    }
} else {
    // Handle invalid request
    echo "Invalid request";
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
         .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
            #navigationbar{
                background-color: #14076F !important;
                align-items: center;
            }
            #navigationbar a{
                color: #fff;
            }
            .logo{
                height: auto;
                width: 50px;
                margin-left: 2%;
            }
            center h1{
                position: relative;
                top: 200px;
                color: #14076F ;
            }
    </style>
</head>
  <body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary" id="navigationbar">
    <div class="container-fluid">
        <a href="appointment.php"><img class="logo" src="APSCE_Logo.jpeg"></a>
        <a href="Home.php"><img class="pic" src="menu.png"></a>
    </div>
</nav>

    <center><h1><?php echo $welcome_message; ?></h1></center>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>