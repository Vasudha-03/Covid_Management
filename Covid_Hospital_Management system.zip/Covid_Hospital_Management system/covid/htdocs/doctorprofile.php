<?php
include 'connect.php';

// Initialize variables
$username = '';
$doctorData = null;

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Get the username from the form
    $username = $_POST['username'];

    // Prepare and execute the SQL query to fetch doctor details for the given username
    $sql = "SELECT * FROM doctor_login WHERE NAME = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch data from the database
    $doctorData = $result->fetch_assoc();

    // Close the database connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #F8F8F8;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;
            }
            .firm h1{
                position: relative;
                top: 7px;
            }
            .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
        .container {
            width: 80%;
            margin: 20px auto;
        }

        h1 {
            color: #14076F;
        }

        p {
            color: #14076F;
            margin-bottom: 10px;
        }

        form {
            margin-top: 20px;
        }

        input {
            padding: 8px;
        }

        .submit-button {
            padding: 10px;
            background-color: #14076F;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .update-button {
            padding: 10px;
            background-color: #5B4FB3;
            color: #fff;
            text-decoration: none;
            border: none;
            cursor: pointer;
            display: inline-block;
        }

        .update-button:hover {
            background-color: #3C3279;
        }
    </style>
</head>
<body>
    <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <a href="Home.php"><img class="pic" src="menu.png"> </a> 
        </nav>
    </div>
    <div class="container">
        <h1>Doctor Profile</h1>
        <form method="post">
            <label for="username">Enter Doctor's Name:</label>
            <input type="text" id="username" name="username" value="<?php echo $username; ?>" required>
            <button type="submit" name="submit" class="submit-button">Submit</button>
        </form>

        <?php
        // Display doctor profile if available
        if ($doctorData) {
            ?>
            <p><strong>Name:</strong> <?php echo $doctorData['NAME']; ?></p>
            <p><strong>Qualification:</strong> <?php echo $doctorData['QUALIFICATION']; ?></p>
            <p><strong>Experience:</strong> <?php echo $doctorData['EXPERIENCE']; ?> years</p>
            <p><strong>Gender:</strong> <?php echo $doctorData['GENDER']; ?></p>
            <p><strong>Age:</strong> <?php echo $doctorData['AGE']; ?> years</p>
            <p><strong>Phone:</strong> <?php echo $doctorData['PHONE']; ?></p>

            <!-- Add more details as needed -->

            <!-- Update button to link to the update page -->
            <a class="update-button" href="doctorupdate.php?NAME=<?php echo $doctorData['NAME']; ?>">Update</a>
            <?php
        } elseif ($username !== '') {
            // Handle the case where the user is not found
            echo "<p>Doctor profile not found for the given name.</p>";
        }
        ?>
    </div>
</body>
</html>
