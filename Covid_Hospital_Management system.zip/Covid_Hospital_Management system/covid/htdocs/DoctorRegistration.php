<?php
include 'connect.php';

if (isset($_POST['submit'])) {
    $NAME = $_POST['name'];
    $PHONE = $_POST['phone'];

    // Check if the phone number already exists
    $sqlCheck = "SELECT * FROM doctor_login WHERE PHONE=?";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("s", $PHONE);
    $stmtCheck->execute();
    $stmtCheck->store_result();

    if ($stmtCheck->num_rows > 0) {
        ?>
        <script type="text/javascript">alert("Phone number already exists!");</script>
        <?php
    } else {
        // Continue with the registration process
        $QUALIFICATION = $_POST['qualification'];
        $EXPERIENCE = $_POST['experience'];
        $GENDER = $_POST['gender'];
        $AGE = $_POST['age'];
        $ID = $_POST['id'];
        $PASSWORD = $_POST['password'];
        $CONFIRMPASSWORD = $_POST['confirmpassword'];

        // Check if Password and Confirm Password match
        if ($PASSWORD !== $CONFIRMPASSWORD) {
            ?>
            <script type="text/javascript">alert("Password and Confirm Password not matched");</script>
            <?php
        } else {
            // Insert data into the database
            $sqlInsert = "INSERT INTO doctor_login (NAME, QUALIFICATION, EXPERIENCE, GENDER, AGE, ID, PHONE, PASSWORD, CONFIRMPASSWORD) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmtInsert = $conn->prepare($sqlInsert);
            $stmtInsert->bind_param("sssssssss", $NAME, $QUALIFICATION, $EXPERIENCE, $GENDER, $AGE, $ID, $PHONE, $PASSWORD, $CONFIRMPASSWORD);
            $result = $stmtInsert->execute();

            if ($result) {
                ?>
                <script type="text/javascript">
                    alert("Data saved successfully!");
                    window.location.href = "doctorhome.php";
                </script>
                <?php
            } else {
                ?>
                <script type="text/javascript">alert("Error inserting data!");</script>
                <?php
            }
            $stmtInsert->close();
        }
    }

    $stmtCheck->close();
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Registration</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            box-sizing: border-box;
            background-color: #F8F8F8;
        }

        .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            #signup{
                background:#14076F ;
                height:50px ;
               margin-left: 20%;
               margin-right: 20%;
               align-items: center;
               justify-content: center;
               display:block;
               /*border-radius: 35%;*/
                font-size: 13px;
                border-radius: 25px;

            }
            .firm h1{
                position: relative;
                top: 7px;
            }
        nav {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

       .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
           

        .firm {
            width: 300px;
            margin: 1% auto;
            background: transparent;
            text-align: center;
            color: #14076F;
            
        }

        #signup {
            background: #14076F;
            height: 50px;
            width: 200px;
            border-radius: 25px;
            font-size: 15px;
            color: white;
            flex: left;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }

        label {
            display: block;
            text-align: left;
            margin-top: 10px;
            color: #14076F;
        }

        input, select {
            width: 100%;
            padding: 6px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn{
                width: 100px;
                height: 40px;
                background: #14076F;
                border: none;
                position:center;
                font-size: 18px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
                color: #fff;
                text-decoration: none;
                transition: .3s
            }
            
            .btn:hover{
                background-color: #5B4FB3;
                color: #fff;
            }

        p {
            color: #14076F;
            margin-top: 20px;
        }
        p a{
            text-decoration: none;
            color: #14076F ;
        }
        #loginform h1{
            font-size: 15px;
        }
    </style>
</head>
<body>
    <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <a href="home.php"><img class="pic" src="menu.png"></a>
        </nav>
    </div>
    <div class="firm">
        <div id="signup"><h1>Registration</h1></div>
        <form method="post" name="userlogin" id="loginform">
            <h1>Doctor Details</h1>
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>

            <label for="qualification">Qualification</label>
            <input type="text" id="qualification" name="qualification" required>

            <label for="experience">Experience</label>
            <input type="number" id="experience" name="experience" required>

            <label for="gender">Select Gender</label>
            <select id="gender" name="gender" required>
                <option value="">Select</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="others">Others</option>
            </select>

            <label for="age">Age</label>
            <input type="number" id="age" name="age" required>

            <label for="id">ID</label>
            <input type="text"  name="id" required>

            <label for="phone">Phone</label>
            <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" required>
            <label>Password</label>
            <input type="text" name="password" required>
            <label>Confirm Password</label>
            <input type="text" name="confirmpassword" required>
            <h5 id="heading3"> Note: Please fill all the details</h5>
            <button class="btn" type="submit" name="submit">Submit</button>
        </form>
        <p> Already a Member? <a href="doctorlogin.php">Sign In</a></p>
    </div>
</body>
</html>
