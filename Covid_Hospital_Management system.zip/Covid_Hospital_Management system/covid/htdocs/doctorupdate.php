<?php
include 'connect.php'; // Assuming connect.php contains your database connection code

if(isset($_POST['submit'])){
    $QUALIFICATION = $_POST['qualification'];
    $EXPERIENCE = $_POST['experience'];
    $GENDER = $_POST['gender'];
    $AGE = $_POST['age'];
    $PHONE = $_POST['phone'];
    $PASSWORD = $_POST['password'];
    $CONFIRMPASSWORD = $_POST['confirmpassword'];
    $NAME = $_POST['name'];
   
    if ($PASSWORD !== $CONFIRMPASSWORD) {
        echo "<script>alert('Password and Confirm Password not matched');</script>";
    } else {
        // Prepare and execute the SQL update query
        $sql = "UPDATE doctor_login SET QUALIFICATION=?, EXPERIENCE=?, GENDER=?, AGE=?, PHONE=?, PASSWORD=?, CONFIRMPASSWORD=? WHERE NAME=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssss", $QUALIFICATION, $EXPERIENCE, $GENDER, $AGE, $PHONE, $PASSWORD, $CONFIRMPASSWORD, $NAME);

        if ($stmt->execute()) {
            echo "<script>alert('Data Updated in the Database.'); window.location.href = 'home.php';</script>";
        } else {
            echo "<script>alert('The Update Operation was Unsuccessful');</script>";
        }
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor details updating</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            box-sizing: border-box;
            background-color: #F8F8F8;
        }

        .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            #signup{
                background:#14076F ;
                height:50px ;
                width: 300px;
               align-items: center;
               justify-content: center;
               display:block;
               /*border-radius: 35%;*/
                font-size: 13px;
                border-radius: 25px;

            }
            .firm h1{
                position: relative;
                top: 7px;
            }
        nav {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

       .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
           

        .firm {
            width: 300px;
            margin: 1% auto;
            background: transparent;
            text-align: center;
            color: #14076F;
            
        }

        #signup {
            background: #14076F;
            height: 50px;
            width: 300px;
            border-radius: 25px;
            font-size: 15px;
            color: white;
            flex: left;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }

        label {
            display: block;
            text-align: left;
            margin-top: 10px;
            color: #14076F;
        }

        input, select {
            width: 100%;
            padding: 6px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn{
                width: 100px;
                height: 40px;
                background: #14076F;
                border: none;
                position:center;
                font-size: 18px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
                color: #fff;
                text-decoration: none;
                transition: .3s
            }
            
            .btn:hover{
                background-color: #5B4FB3;
                color: #fff;
            }

        p {
            color: #14076F;
            margin-top: 20px;
        }
        p a{
            text-decoration: none;
            color: #14076F ;
        }
        #loginform h1{
            font-size: 15px;
        }
    </style>
</head>
<body>
    <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <img class="pic" src="menu.png">
        </nav>
    </div>
    <div class="firm">
        <div id="signup"><h1>Update Profile</h1></div>
        <form method="post" name="userlogin" id="loginform">
            <h1>Doctor Details</h1>
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>

            <label for="qualification">Qualification</label>
            <input type="text" id="qualification" name="qualification" required>

            <label for="experience">Experience</label>
            <input type="number" id="experience" name="experience" required>

            <label for="gender">Select Gender</label>
            <select id="gender" name="gender" required>
                <option value="">Select</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="others">Others</option>
            </select>

            <label for="age">Age</label>
            <input type="number" id="age" name="age" required>

            <label for="phone">Phone</label>
            <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" required>
            <label>Password</label>
            <input type="text" name="password" required>
            <label>Confirm Password</label>
            <input type="text" name="confirmpassword" required>
            <button class="btn" type="submit" name="submit">Submit</button>
        </form>
    </div>
</body>
</html>
