<?php


$host='localhost';
$user='root';
$pass='';
$db_name='Covid_management';

$conn=new MYSQLi($host,$user,$pass,$db_name);/*mysqli is a class ,conn is a object*/
if($conn->connect_error)/*-> is an operator for object connect_error is method it returns the errors*/
{
die('database connection error:'.$conn->connect_error);/*die is function it will print the message and it will break*/
}

else{
//echo 'success';
}
?>