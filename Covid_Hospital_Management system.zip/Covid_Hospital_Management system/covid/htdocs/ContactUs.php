<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ContactUS Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">    <style>
      /*body{
        background-image:url(contactus.png) ;
              background-size: cover;
              position: relative;
      }*/
         .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
            #navigationbar{
                background-color: #14076F !important;
                align-items: center;
            }
            #navigationbar a{
                color: #fff;
            }
            .logo{
                height: auto;
                width: 50px;
                margin-left: 2%;
            }
            .heading h2{
             color:#14076F ;
            }
            .container{
              /*background-color: lightgray;*/
              align-items: center;
              height: 550px;
              width: 300%;
              justify-content: space-between;
              display: flex;
              float: left;
              background-image:url(contactus.png) ;
              background-size: cover;
              position: relative;left: 225px;
            }

            .image{
              border-width: 2px;
              border-color: black;
              height: 100%;
              width: 50%;
              float: right;
             

            }
            .guidelines{
              border-width: 2px;
              border-color: black;
              height: 100%;
              width: 100%;
              /*background-color: lightgray;*/
              text-align: right;
              color: blue;
               
              left: 200px;


            }
            .guidelines ul li h5{
               color:#14076F ;
            }
            .guidelines ul  h3{
               color:#14076F ;
               text-align: center;
               margin-top: 5px;
            }
            ul h2{
                text-align: center;
                color: white;
                position: relative;
                left: 500px;
            }
            .contact{
                position: relative;
                left: 30px;
                top: 90px;
                color: #14076F;
            }
           
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary" id="navigationbar">
        <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <img class="logo" src="APSCE_Logo.jpeg">
                    </li>
                    <center><h2>CONTACT US</h2></center>
                </ul>
                <a href="home.php"><img class="pic" src="menu.png"> </a>
            </div>
        </div>
    </nav>
    
   

    <div class="container">
      <div class="image" >
        <div class="contact">
            <h5>Address</h5>
            <h7>Covid Hospital</h7><br>
            <h7>Somanahalli, Kanakapura Road</h7><br>
            <h7>Bengalore-560082</h7><br><br>

            <h5>Contact Info</h5>
            <h6>Email</h6>
            <h7>healthcarecenter@gmail.com</h7><br><br>
            <h6>helpline</h6>
            <h7>080-9264-3452</h7>

        </div>
        
      </div>
    
     </div>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>