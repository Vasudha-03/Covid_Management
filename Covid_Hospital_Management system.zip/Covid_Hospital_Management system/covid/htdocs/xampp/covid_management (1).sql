-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2024 at 04:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covid_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `ID` varchar(50) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `PHONE` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`ID`, `USERNAME`, `PASSWORD`, `PHONE`) VALUES
('1', 'Divya', '', 9874563214),
('2', 'Tejaswini', '', 7845961235),
('3', 'aps', '', 7894561237),
('4', 'vinutha', '', 8741258392),
('5', 'vasudha', '', 4213456789);

-- --------------------------------------------------------

--
-- Table structure for table `consult`
--

CREATE TABLE `consult` (
  `FIRSTNAME` varchar(20) NOT NULL,
  `LASTNAME` varchar(20) NOT NULL,
  `AGE` int(20) NOT NULL,
  `PHONENO` bigint(20) NOT NULL,
  `GENDER` varchar(20) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `ADHAR` bigint(20) NOT NULL,
  `VISIT` varchar(50) NOT NULL,
  `STATUS` varchar(20) NOT NULL,
  `ADDRESS` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consult`
--

INSERT INTO `consult` (`FIRSTNAME`, `LASTNAME`, `AGE`, `PHONENO`, `GENDER`, `EMAIL`, `ADHAR`, `VISIT`, `STATUS`, `ADDRESS`) VALUES
('suma', 'h s', 41, 9901802962, 'Female', 'suma@gmail.com', 789456123369, 'cough,cold', 'accepted', 'bangalore'),
('divya', 'h s', 50, 8951902393, 'Female', 'divyaammu10680@gmail.com', 789456123369, 'fever', '', 'mysore'),
('vinutha', 'h s', 0, 8874551456, 'Female', 'divyaammu10680@gmail.com', 632248099583, 'fever', '', 'banglore');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_login`
--

CREATE TABLE `doctor_login` (
  `NAME` varchar(50) NOT NULL,
  `QUALIFICATION` varchar(50) NOT NULL,
  `EXPERIENCE` int(50) NOT NULL,
  `GENDER` varchar(20) NOT NULL,
  `AGE` int(20) NOT NULL,
  `ID` varchar(50) NOT NULL,
  `PHONE` bigint(20) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL,
  `CONFIRMPASSWORD` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_login`
--

INSERT INTO `doctor_login` (`NAME`, `QUALIFICATION`, `EXPERIENCE`, `GENDER`, `AGE`, `ID`, `PHONE`, `PASSWORD`, `CONFIRMPASSWORD`) VALUES
('Preethi', 'gynecologist', 4, 'Female', 41, '5a32y', 9874551456, 'preethi@123', 'preethi@123'),
('yashaswini', 'cardiolagist', 10, 'Female', 67, '98po9', 8951902393, 'yashu', 'yashu');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `FIRSTNAME` varchar(50) NOT NULL,
  `LASTNAME` varchar(50) NOT NULL,
  `AGE` int(20) NOT NULL,
  `PHONENO` bigint(20) NOT NULL,
  `GENDER` varchar(20) NOT NULL,
  `BLOODGROUP` varchar(20) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  `ADHAR` bigint(20) NOT NULL,
  `STATUS` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`FIRSTNAME`, `LASTNAME`, `AGE`, `PHONENO`, `GENDER`, `BLOODGROUP`, `EMAIL`, `ADDRESS`, `ADHAR`, `STATUS`) VALUES
('yashwanth', 's', 20, 9901802962, 'Male', 'A+ve', 'xyz@gmail.com', 'bangalore', 789456123369, 'accepted'),
('suresh', 'a', 21, 5478996123, 'Male', 'A-ve', 'suresh@gmail.com', 'mangalore\r\n', 789456123369, 'accepted'),
('abc', 'L', 41, 9901802962, 'Female', 'B+ve', 'preethiksp057@gmail.com', 'retyh', 632248099583, '');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `USERNAME` varchar(50) NOT NULL,
  `PHONE` bigint(20) NOT NULL,
  `PASSWORD` varchar(100) NOT NULL,
  `CONFIRMPASSWORD` varchar(100) NOT NULL,
  `ADHAR` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`USERNAME`, `PHONE`, `PASSWORD`, `CONFIRMPASSWORD`, `ADHAR`) VALUES
('vinutha', 0, 'vinutha@123', 'vinutha@123', 435323454467),
('mohan', 7894561237, 'mohan@123', 'mohan@123', 632248099583),
('ranjitha', 9874551456, 'ranjitha@123', 'ranjitha@123', 789456123369);

-- --------------------------------------------------------

--
-- Table structure for table `vaccine`
--

CREATE TABLE `vaccine` (
  `FIRSTNAME` varchar(50) NOT NULL,
  `LASTNAME` varchar(50) NOT NULL,
  `AGE` int(20) NOT NULL,
  `ADHAR` bigint(20) NOT NULL,
  `PHONENO` bigint(20) NOT NULL,
  `GENDER` varchar(20) NOT NULL,
  `DOSAGE` varchar(50) NOT NULL,
  `DATES` date NOT NULL,
  `EMAIL` varchar(40) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  `STATUS` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vaccine`
--

INSERT INTO `vaccine` (`FIRSTNAME`, `LASTNAME`, `AGE`, `ADHAR`, `PHONENO`, `GENDER`, `DOSAGE`, `DATES`, `EMAIL`, `ADDRESS`, `STATUS`) VALUES
('sumithra', 'R', 41, 632248099583, 7894561237, 'Female', 'Second', '2024-04-04', 'sumithra@gmail.com', 'bangalore\r\n', ''),
('ramya', 's', 41, 632248099583, 7894561237, 'Female', 'Second', '2024-04-04', 'ramya@gmail.com', 'bangalore', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `consult`
--
ALTER TABLE `consult`
  ADD KEY `ADHAR` (`ADHAR`);

--
-- Indexes for table `doctor_login`
--
ALTER TABLE `doctor_login`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD KEY `ADHAR` (`ADHAR`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`ADHAR`);

--
-- Indexes for table `vaccine`
--
ALTER TABLE `vaccine`
  ADD KEY `ADHAR` (`ADHAR`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `consult`
--
ALTER TABLE `consult`
  ADD CONSTRAINT `consult_ibfk_1` FOREIGN KEY (`ADHAR`) REFERENCES `user_login` (`ADHAR`);

--
-- Constraints for table `test`
--
ALTER TABLE `test`
  ADD CONSTRAINT `test_ibfk_1` FOREIGN KEY (`ADHAR`) REFERENCES `user_login` (`ADHAR`);

--
-- Constraints for table `vaccine`
--
ALTER TABLE `vaccine`
  ADD CONSTRAINT `vaccine_ibfk_1` FOREIGN KEY (`ADHAR`) REFERENCES `user_login` (`ADHAR`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
