
<?php
include 'connect.php';

if (isset($_POST['submit'])) {
    $USERNAME = $_POST['username'];
    $PHONE = $_POST['phone'];
    $PASSWORD = $_POST['password'];
    $CONFIRMPASSWORD = $_POST['confirmpassword'];
    $ADHAR = $_POST['adhar'];

   
    if ($PASSWORD !== $CONFIRMPASSWORD) {
        ?>
        <script type="text/javascript">alert("Password and Confirm Password not matched");</script>

        <?php
    } else {
        $sql = "SELECT * FROM user_login WHERE USERNAME=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $USERNAME);
        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            ?>
            <script type="text/javascript">alert("Data already exists!");</script>
            <?php
        } else {
            // Template for SQL query
            $sql = "INSERT INTO user_login (USERNAME, PHONE, PASSWORD, CONFIRMPASSWORD,ADHAR) VALUES (?, ?, ?, ?, ?)";
            // Preparing the statement
            $stmt = $conn->prepare($sql);
            // Bind all data with actual values from placeholder like ?
            $stmt->bind_param("sssss", $USERNAME, $PHONE, $PASSWORD, $CONFIRMPASSWORD,$ADHAR);
            $result = $stmt->execute();

            if ($result) {
                ?>
                <script type="text/javascript">
                    alert("Data saved successfully!");
                    window.location.href = "usersign.php";
                </script>
                <?php
                
            } else {
                ?>
                <script type="text/javascript">alert("Error inserting data!");</script>
                <?php
            }
        }
    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Sign Up</title>
   <style>
            body {
                margin: 0;
                padding: 0;
                font-family: Arial, sans-serif;
                box-sizing: border-box;
            }
            .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            #signup{
                background:#14076F ;
                height:50px ;
               margin-left: 20%;
               margin-right: 20%;
               align-items: center;
               justify-content: center;
               display:block;
               /*border-radius: 35%;*/
                font-size: 13px;
                border-radius: 25px;

            }
        
            .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
            
            .firm h1{
                position: relative;
                top: 7px;
            }
               
            .firm{
                position: center;
                width: 400px;
                height: 520px;
                margin: 5% auto;
                margin-top: 1px;
                background:transparent;
                text-align:center;
                color: white;
                background: white;
                /*border-radius: 5%;*/
                /*border: 1px solid black;*/
            }
            
            .firm form{
                padding:0 40px;
            }
            form .txt_field{
                position: relative;
                border-bottom: 2px solid #adadad;
                margin: 30px 0;
            }
            .txt_field input{
                width: 100%;
                padding: 0 5px;
                height: 40px;
                font-size: 14px;
                border: none;
                background: none;
                outline: none;
                
            }
            .txt_field label{
                position: absolute;
                top: 50%;
                left: 5px;
                color:#14076F;
                transform: translateY(-50%);
                font-size: 16px;
                pointer-events: none;
                transition: 0.3s;

            }
            .txt_field span::before{
                content: '';
                position: absolute;
                top: 40px;
                left: 0;
                width: 0%;
                height: 2px;
                background:#14076F;
                transition: 0.3s;
            }
            .txt_field input:focus ~ label,
            .txt_field input:valid ~ label{
                top: -5px;
                color:#14076F;
            }
            .txt_field input:focus ~ span::before,
            .txt_field input:valid ~ span::before{
                width: 100%;
            }
            .cn{
                width: 100px;
                height: 40px;
                background: #14076F;
                border: none;
                position:center;
                font-size: 18px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
                color: #fff;
                text-decoration: none;
                transition: .3s
            }
            
            .cn:hover{
                background-color: #5B4FB3;
                color: #fff;
            }
            .pa{
                color: #000;
            }
            .firm p{
                color: #000;
            }
            .firm p a{
                text-decoration: none;
                color: black;
            }
        </style>
</head>
<body>
    <div class="con">
    <nav>
        <img class="logo" src="APSCE_Logo.jpeg">
       
        <a href="home.php"><img class="pic" src="menu.png"></a>      
       
    </nav>
    </div>
    <div class="firm">
        <br>
        <div id="signup"><h1>Registration</h1></div>
        <form method="post" name="userlogin" id="loginform">
            <div class="txt_field">
                <input type="text" name="username" required>
                <span></span>
                <label>User Name</label>
            </div>
            <div class="txt_field">
                <input type="text" name="phone" required>
                <span></span>
                <label>Phone no</label>
            </div>
            <div class="txt_field">
                <input type="tel" pattern="[0-9]{12}" maxlength="12" name="adhar"required>
                <span></span>
                <label>Adhar Number</label>
            </div>
            <div class="txt_field">
                <input type="text" name="password" required>
                <span></span>
                <label>Password</label>
            </div>
            <div class="txt_field">
                <input type="text" name="confirmpassword" required>
                <span></span>
                <label>Confirm Password</label>
            </div>
            <button class="cn" name="submit" type="submit">Sign Up</button><br>
        </form>
        <p> Already a Member? <a href="usersign.php">Sign In</a></p>
    </div>
</body>
</html>
