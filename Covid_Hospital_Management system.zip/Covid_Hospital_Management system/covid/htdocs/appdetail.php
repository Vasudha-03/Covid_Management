<?php
include 'connect.php';

$USERNAME = '';
$dataTest = [];
$dataVaccine = [];
$dataconsult = [];
$noAppointmentsFound = false;

if (isset($_POST['submit'])) {
    // Get the username from the form
    $USERNAME = $_POST['username'];

    // Fetch data from the "test" table for the entered username
    $sqlTest = "SELECT * FROM test1 WHERE FIRSTNAME = '$USERNAME' OR LASTNAME = '$USERNAME'";
    $resultTest = $conn->query($sqlTest);
    $dataTest = $resultTest->fetch_all(MYSQLI_ASSOC);

    // Fetch data from the "vaccine" table for the entered username
    $sqlVaccine = "SELECT * FROM vaccine WHERE FIRSTNAME = '$USERNAME' OR LASTNAME = '$USERNAME'";
    $resultVaccine = $conn->query($sqlVaccine);
    $dataVaccine = $resultVaccine->fetch_all(MYSQLI_ASSOC);

    // Fetch data from the "consult" table for the entered username
    $sqlconsult = "SELECT * FROM con WHERE FIRSTNAME = '$USERNAME' OR LASTNAME = '$USERNAME'";
    $resultconsult = $conn->query($sqlconsult);
    $dataconsult = $resultconsult->fetch_all(MYSQLI_ASSOC);

    if (empty($dataTest) && empty($dataVaccine) && empty($dataconsult)) {
        $noAppointmentsFound = true;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>see sheduled Appointment </title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #F8F8F8;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;
            }
            .firm h1{
                position: relative;
                top: 7px;
            }
            .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
        .container {
            width: 80%;
            margin: 20px auto;
        }

        h1 {
            color: #14076F;
        }

        p {
            color: #14076F;
            margin-bottom: 10px;
        }

        form {
            margin-top: 20px;
        }

        input {
            padding: 8px;
        }

        .submit-button {
            padding: 10px;
            background-color: #14076F;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .update-button {
            padding: 10px;
            background-color: #5B4FB3;
            color: #fff;
            text-decoration: none;
            border: none;
            cursor: pointer;
            display: inline-block;
        }

        .update-button:hover {
            background-color: #3C3279;
        }
    </style>
</head>
<body>
    <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <a href="Home.php"><img class="pic" src="menu.png"> </a> 
        </nav>
    </div>
    <div class="container">
        <h1>Appointment Details</h1>
        <form method="post">
            <label for="username">Enter Name:</label>
            <input type="text" id="username" name="username" value="<?php echo $USERNAME; ?>" required>
            <button type="submit" name="submit" class="submit-button">Submit</button>
        </form>
        <div>
            <?php if ($noAppointmentsFound) : ?>
                <p>No appointments found for <?php echo $USERNAME; ?>.</p>
            <?php endif; ?>

            <?php if (!empty($dataTest)) : ?>
                <h2>Test Appointments</h2>
                <?php foreach ($dataTest as $row) : ?>
                    <p><strong>Adhar:</strong> <?php echo $row['ADHAR']; ?></p>
                    <p><strong>Patient Name:</strong> <?php echo $row['FIRSTNAME'] . ' ' . $row['LASTNAME']; ?></p>
                    <p><strong>Status:</strong> <?php echo $row['STATUS']; ?></p>
                <?php endforeach; ?>
            <?php endif; ?>

            <?php if (!empty($dataVaccine)) : ?>
                <h2>Vaccine Appointments</h2>
                <?php foreach ($dataVaccine as $row) : ?>
                    <p><strong>Adhar:</strong> <?php echo $row['ADHAR']; ?></p>
                    <p><strong>Patient Name:</strong> <?php echo $row['FIRSTNAME'] . ' ' . $row['LASTNAME']; ?></p>
                    <p><strong>Status:</strong> <?php echo $row['STATUS']; ?></p>
                <?php endforeach; ?>
            <?php endif; ?>

            <?php if (!empty($dataconsult)) : ?>
                <h2>Consultation Appointments</h2>
                <?php foreach ($dataconsult as $row) : ?>
                    <p><strong>Adhar:</strong> <?php echo $row['ADHAR']; ?></p>
                    <p><strong>Patient Name:</strong> <?php echo $row['FIRSTNAME'] . ' ' . $row['LASTNAME']; ?></p>
                    <p><strong>Status:</strong> <?php echo $row['STATUS']; ?></p>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
