<?php
include 'connect.php';
// Fetch data from the "test" table
$sqlTest = "SELECT * FROM test1";
$resultTest = $conn->query($sqlTest);
$dataTest = $resultTest->fetch_all(MYSQLI_ASSOC);

// Fetch data from the "vaccine" table
$sqlVaccine = "SELECT * FROM vaccine";
$resultVaccine = $conn->query($sqlVaccine);
$dataVaccine = $resultVaccine->fetch_all(MYSQLI_ASSOC);

$sqlconsult = "SELECT * FROM con";
$resultconsult = $conn->query($sqlconsult);
$dataconsult = $resultconsult->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Data</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #F8F8F8;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            
            .firm h1{
                position: relative;
                top: 7px;
            }
            .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
        .container {
            width: auto;
            margin: 20px auto;
            margin: 2em;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 5px;
            text-align: left;
        }

        th {
            background-color: #14076F;
            color: #fff;
        }
        button {
            width: 120px;
            height: 30px;
            background: #14076F;
            border: none;
            position:center;margin-top: 10%;
            font-size: 18px;
            border-radius: 20px;
            cursor: pointer;
            transition: .4s ease;
            color: #fff;
            text-decoration: none;
            transition: .3s
        }

        button:hover {
            background: #5B4FB3;
        } 
        .cn {
            width: 150px;
            height: 30px;
            background: #14076F;
            border: none;
            position:center;margin-top: 10%;
            font-size: 18px;
            border-radius: 20px;
            cursor: pointer;
            transition: .4s ease;
            color: #fff;
            text-decoration: none;
            transition: .3s
        }

        .cn:hover {
            background: #5B4FB3;
        } 
        a{
            text-decoration: none;
            color: #fff;
        }
        a:hover{color: #fff;
        }
    </style>
</head>

<body>
    <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <a href="home.php"><img class="pic" src="menu.png"></a>
        </nav>
    </div>

    <div class="container">
        <!-- Display data from the "test" table -->
        <h2>Appointment for Test </h2>
        <table>
            <tr>
                <th>Adhar</th>
                <th>Patient Name</th>
                <th>Status</th>
            </tr>
            <?php foreach ($dataTest as $row) : ?>
                <tr>
                    <td><?php echo $row['ADHAR']; ?></td>
                    <td><?php echo $row['FIRSTNAME']; ?>
                        <?php echo $row['LASTNAME']; ?>
                    </td>
                    <td><?php echo $row['STATUS']; ?></td>
                </tr>
            <?php endforeach; ?>
    
        </table>

        <!-- Display data from the "vaccine" table -->
        <h2>Appointment for Vaccine </h2>
        <table border="1">
            <tr>
            <th>Adhar</th>
            <th>Patient Name</th>
            <th>Status</th>
        </tr>
        <?php foreach ($dataVaccine as $row) : ?>
            <tr>
                <td><?php echo $row['ADHAR']; ?></td>
                <td><?php echo $row['FIRSTNAME']; ?>
                    <?php echo $row['LASTNAME']; ?>
                </td>
                <td><?php echo $row['STATUS']; ?></td>
            </tr>
        <?php endforeach; ?>
        </table>

        <!-- Display data from the "consult" table -->
        <h2>Appointment for Consult </h2>
        <table border="1">
            <tr>
            <th>Adhar</th>
            <th>Patient Name</th>
            <th>Status</th>
        </tr>
        <?php foreach ($dataconsult as $row) : ?>
            <tr>
                <td><?php echo $row['ADHAR']; ?></td>
                <td><?php echo $row['FIRSTNAME']; ?>
                    <?php echo $row['LASTNAME']; ?>
                </td>
                <td><?php echo $row['STATUS']; ?></td>
                
            </tr>
        <?php endforeach; ?>
        </table>
    </div>
</body>
