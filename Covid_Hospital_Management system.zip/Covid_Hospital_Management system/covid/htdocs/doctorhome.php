<?php
include 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>submit</title>
        <style>
	        body {
                margin: 0;
                padding: 0;
                font-family: Arial, sans-serif;
                color: #fff;
            }
            .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            #signup{
                background:#14076F ;
                height:50px ;
               margin-left: 20%;
               margin-right: 20%;
               align-items: center;
               justify-content: center;
               display:block;
               /*border-radius: 35%;*/
                font-size: 13px;
                border-radius: 25px;

            }
            .firm h1{
                position: relative;
                top: 7px;
            }
        nav {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

       .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
           
            .form{
                margin-top: 18%;
                margin-left: 31%;
            }
            .view{
                width: 270px;
                height: 65px;
                background: #14076F;
                border: none;
                font-size: 28px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
            }
            .view a{
                color: #fff;
                text-decoration: none;
            }
            .appo{
                width: 270px;
                height: 65px;
                margin-left: 3%;
                background: #14076F;
                border: none;
                font-size: 28px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
            }
            .appo a{
                color: #fff;
                text-decoration: none;
            }
        </style>
    </head>
    <body>
        <div class="con">
            <nav>
                <img class="logo" src="APSCE_Logo.jpeg">
       
                <a href="home.php"><img class="pic" src="menu.png"></a>
       
            </nav>
        </div>
        <div class="form">
            <button class="view"><a href="doctorprofile.php"> Profile View</a></button>
            <button class="appo"><a href="appointment.php"> Appointment</a></button>
        </div>
    </body>
</html>