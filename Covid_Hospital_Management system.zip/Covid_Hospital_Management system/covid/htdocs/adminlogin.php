<?php
include 'connect.php';
session_start();

if (isset($_POST['submit'])) {
    $ID = $_POST['id'];
    $PASSWORD = $_POST['password'];
    
    $sql = "SELECT ID, Username, PASSWORD FROM adminlogin WHERE ID=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $ID);
    $stmt->execute();

    $stmt->bind_result($db_id, $db_Username, $db_password);/*storing id, username, and password*/
    if ($stmt->fetch()) {
        $_SESSION['USERNAME'] = $db_Username;
        //echo $_SESSION['USERNAME'];
        /*fetching the data*/

        if ($PASSWORD == "apsce@123") {
            header("location: access.php");
        } else {
            ?>
            <script type="text/javascript" >alert("Incorrect password");</script>
            <?php
        }
    } else {
        /*if no id*/
        ?>
        <script type="text/javascript" >alert("Incorrect admin id");</script>
        <?php
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>

    <style type="text/css">
        .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            #signup{
                background:#14076F ;
                height:50px ;
               margin-left: 20%;
               margin-right: 20%;
               align-items: center;
               justify-content: center;
               display:block;
               /*border-radius: 35%;*/
                font-size: 13px;
                border-radius: 25px;

            }
            .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }

            .firm h1{
                position: relative;
                top: 7px;
            }
               
            .firm{
                position: center;
                width: 400px;
                height: 520px;
                margin: 5% auto;
                margin-top: 1px;
                background:transparent;
                text-align:center;
                color: white;
                background: white;
                /*border-radius: 5%;*/
                /*border: 1px solid black;*/
            }

            .firm form{
                padding:0 40px;
            }
            form .txt_field{
                position: relative;
                border-bottom: 2px solid #adadad;
                margin: 30px 0;
            }
            .txt_field input{
                width: 100%;
                padding: 0 5px;
                height: 40px;
                font-size: 16px;
                border: none;
                background: none;
                outline: none;
                
            }
            .txt_field label{
                position: absolute;
                top: 50%;
                left: 5px;
                color:#14076F;
                transform: translateY(-50%);
                font-size: 20px;
                pointer-events: none;
                transition: 0.3s;

            }
            .txt_field span::before{
                content: '';
                position: absolute;
                top: 40px;
                left: 0;
                width: 0%;
                height: 2px;
                background:#14076F;
                transition: 0.3s;
            }
            .txt_field input:focus ~ label,
            .txt_field input:valid ~ label{
                top: -5px;
                color:#14076F;
            }
            .txt_field input:focus ~ span::before,
            .txt_field input:valid ~ span::before{
                width: 100%;
            }
            .cn{
                width: 100px;
                height: 40px;
                background: #14076F;
                border: none;
                position:center;
                font-size: 18px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
                color: #fff;
                text-decoration: none;
                transition: .3s
            }
            
            .cn:hover{
                background-color: #5B4FB3;
                color: #fff;
            }
            .pa{
                color: #000;
            }
            .firm p{
                color: #000;
                font-size: 19px;
            }
            .firm p a{
                text-decoration: none;
                color: black;
            }
    </style>
</head>
<body>
        <div class="con">
                <nav>
                        <img class="logo" src="APSCE_Logo.jpeg">
       
                        <a href="home.php"><img class="pic" src="menu.png"></a>   
       
                </nav>
        </div>
<br>
<div class="firm">
        <form method="post" action="">

                <div id="signup"><h1>Login</h1></div>
                <div class="txt_field">
                        <input type="text" name="id"   required>
                        <span></span>
                        <label for="id">ID</label>
                </div>
                <div class="txt_field">
                        <input type="password" name="password"   required>
                        <span></span>
                        <label for="password">Password</label>
                </div>
                        <button class="cn" name="submit" type="submit">SUBMIT</button><br><br>
                        <p>Not a member?<a href="adminRegistration.php">Sign up</a></p>

        </form>
</div>
</body>
</html>