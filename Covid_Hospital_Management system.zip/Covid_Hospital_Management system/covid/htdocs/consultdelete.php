<?php
include 'connect.php';

if (isset($_POST['submit'])) {
    $FIRSTNAME = $_POST['firstname'];
    $sql = "DELETE FROM consult WHERE FIRSTNAME = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $FIRSTNAME);
    $result = $stmt->execute();

    if ($result) {
        $affectedRows = $stmt->affected_rows;

        if ($affectedRows > 0) {
            ?>
            <script>
                alert("Record Successfully Deleted from the Database.");
                window.location.href = "adminviewapp.php";
            </script>
        <?php
        } else {
            ?>
            <script>
                alert("No record found with the specified ADHAR. Please check the ADHAR and try again.");
            </script>
        <?php
        }
    } else {
        ?>
        <script>
            alert("The delete operation was unsuccessful.");
        </script>
    <?php
    }
}
?>
<!DOCTYPE html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deleting Doctor Profile</title>
    <style>
      body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            box-sizing: border-box;
            background-color: #F8F8F8;
        }

        .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            #signup{
                background:#14076F ;
                height:50px ;
               margin-left: 20%;
               margin-right: 20%;
               align-items: center;
               justify-content: center;
               display:block;
               /*border-radius: 35%;*/
                font-size: 1px;
                border-radius: 25px;

            }
            .firm h1{
                position: relative;
                top: 7px;
                font-size: 25px;
            }
        nav {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

       .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
           

        .firm {
            width: 300px;
            margin: 1% auto;
            background: transparent;
            text-align: center;
            color: #14076F;
            
        }

        #signup {
            background: #14076F;
            height: 50px;
            width: 350px;
            border-radius: 25px;
            font-size: 15px;
            color: white;
            align-items: center;
            justify-content: center;
            margin-left: -23px;
            margin-bottom: 30px;
        }

        label {
            display: block;
            text-align: left;
            margin-top: 10px;
            color: #14076F;
        }

        input, select {
            width: 100%;
            padding: 6px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn{
                width: 100px;
                height: 40px;
                background: #14076F;
                border: none;
                position:center;
                font-size: 18px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
                color: #fff;
                text-decoration: none;
                transition: .3s
            }
            
            .btn:hover{
                background-color: #5B4FB3;
                color: #fff;
            }

        p {
            color: #14076F;
            margin-top: 20px;
        }
        p a{
            text-decoration: none;
            color: #14076F ;
        }
        #loginform h1{
            font-size: 15px;
        }
    </style>
  </head>
  <body>
    <div class="con">
      <nav>   
        <img class="logo" src="APSCE_Logo.jpeg">
        <a href="Home.php"><img class="pic" src="menu.png"> </a>       
      </nav>
    </div>
    <div class="firm">
      <div id="signup"><h1>DELETE THE DETAILS</h1></div>
      <form  action="" method="post" enctype="multiple/form-data">
        <label >FIRSTNAME</label><br>
        <input type="text" name="firstname" placeholder="Enter the FIRSTNAME" required>
        <br><br>
        <button name="submit" class="btn">SUBMIT</button><br><br>
      </form>
    </div>
  </body>
</html>
