<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>view appointment</title>
        <style>
	        body {
                margin: 0;
                padding: 0;
                font-family: Arial, sans-serif;
                color: #fff;
            }
            .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;
            }

            .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
           
            .firm {
            width: 300px;
            margin: 1% auto;
            background: transparent;
            text-align: center;
            color: #14076F;
            
            }

            label{
                font-size: 20px;
            }
            .cn{
                width: 100px;
                height: 40px;
                background: #14076F;
                border: none;
                position:center;margin-top: 10%;
                font-size: 18px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
                color: #fff;
                text-decoration: none;
                transition: .3s
            }
            
            .cn:hover{
                background-color: #5B4FB3;
                color: #fff;
            }
            .cn a{
                text-decoration: none;
                color: #fff;
            }
            a:hover{color: #fff;
            }
        </style>
    </head>
    <body>
        <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <a href="home.php"><img class="pic" src="menu.png"></a>
        </nav>
    </div>
        <div class="firm">
            <br><h1>Thank You</h1>
                <center><label>Your Application Has Been Sent</label></center>
            <button class="cn"><a href="appdetail.php"> View</a></button><br>
        </div>
    </body>
</html>