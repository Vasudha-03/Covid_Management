<?php
session_start();

// Check if the username is stored in the session
if (isset($_SESSION['USERNAME'])) {
    $welcome_message = "Welcome, " . $_SESSION['USERNAME'] . "!";
} else {
    // If not, redirect to the login page
    header("location: usersign.php");
    exit();
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Purpose Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
         .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
            #navigationbar{
                background-color: #14076F !important;
                align-items: center;
            }
            #navigationbar a{
                color: #fff;
            }
            .logo{
                height: auto;
                width: 50px;
                margin-left: 2%;
            }
            center h1{
                position: relative;
                top: 200px;
                color: #14076F ;
            }
    </style>
</head>
  <body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary" id="navigationbar">
        <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <img class="logo" src="APSCE_Logo.jpeg">
                    </li>
                  
                  <li class="nav-item">
                    <a class="nav-link" href="test.php">Test</a>
                  </li>
                  <li class="nav-item">
                  <a class="nav-link" href="vaccine.php">Vaccine</a>
                  </li>
                  <li class="nav-item">
                  <a class="nav-link" href="consult.php">Consult</a>
                  </li>
                  <li class="nav-item">
                  <a class="nav-link" href="userprofile.php">View Profile</a>
                  </li>
                  <li class="nav-item">
                  <a class="nav-link" href="submited.php">View Appointment</a>
                  </li>
                </ul>
                <a href="Home.php"><img class="pic" src="menu.png"> </a>   
        </div>
    </nav>
    <center><h1><?php echo $welcome_message; ?></h1></center>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>