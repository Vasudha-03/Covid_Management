<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patients Details</title>
    <style type="text/css">
        body {
            display: flex;
            flex-direction: column;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .con {
            display: block;
            align-items: left;
            height: 9%;
            width: 100%;
            justify-content: center;
            background-color: #14076F;
        }

        

        .logo {
            height: 60px;
            width: auto;
            margin-left: 20px;
        }

        .pic {
            margin-top: 10px;
            height: 30px;
            width: 50px;
            float: right;
            margin-right: 20px;
        }

        .container {
            text-align: center;
            margin-top: 20px;
        }

        .card {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 20px;
        }

        .card-item {
            background: #fff;
            border: 2px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            width: 300px;
            max-height: 100%;
        }

        a {
            text-decoration: none;
            color: white;
        }

        button {
            width: 80px;
            height: 30px;
            background: #14076F;
            border: none;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
            transition: .4s ease;
            color: #fff;
            text-decoration: none;
        }

        button:hover {
            background: #5B4FB3;
        }
    </style>
</head>

<body>
    <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <a href="Home.php"><img class="pic" src="menu.png"></a>
        </nav>
    </div>

    <div class="container">
        <h2>Patient Profile</h2>
    </div>

    <div class="card">
        <?php
        $sql = "SELECT * FROM user_login";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result(); /*result will be stored return the result query*/

        while ($row = $result->fetch_assoc()) {
        ?>
            <div class="card-item">
                <p><strong>Name:</strong> <?php echo $row['USERNAME']; ?></p>
                <p><strong>Phone no:</strong> <?php echo $row['PHONE']; ?></p>
                <p><strong>Adhar no:</strong> <?php echo $row['ADHAR']; ?></p>
                <button><a href="userupdate.php?USERNAME=<?php echo $row['USERNAME']; ?>">UPDATE</a></button>
                
            </div>
        <?php
        }
        ?>
    </div>

</body>

</html>
