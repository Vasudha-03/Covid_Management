<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">    <style>
     /* body{
        background-image: URL(Covid.png);
        background-repeat: no-repeat;
        position: relative;

      }*/
         .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
            #navigationbar{
                background-color: #14076F !important;
                align-items: center;
            }
            #navigationbar a{
                color: #fff;
            }
            .logo{
                height: auto;
                width: 50px;
                margin-left: 2%;
            }
            .heading h2{
             color:#14076F ;
            }
            .container{
              /*background-color: lightgray;*/
              align-items: center;
              height: 550px;
              width: 300%;
              justify-content: space-between;
              display: flex;
              float: left;
            }

            .image{
              border-width: 2px;
              border-color: black;
              height: 100%;
              width: 80%;
              /*float: left;*/
              background-image:url(Covid.png) ;
              background-size: cover;
              position: center;

            }
            .guidelines{
              border-width: 2px;
              border-color: black;
              height: 100%;
              width: 50%;
              /*background-color: lightgray;*/
              text-align: left;
              color: blue;

            }
            .guidelines ul li h5{
               color:#14076F ;
            }
            .guidelines ul  h3{
               color:#14076F ;
               text-align: center;
               margin-top: 5px;
            }
           
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary" id="navigationbar">
        <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <img class="logo" src="APSCE_Logo.jpeg">
                    </li>
                  <li class="nav-item">
                    <a class="nav-link" href="usersign.php">User</a>
                  </li>
                  <li class="nav-item">
                  <a class="nav-link" href="adminlogin.php">Admin</a>
                  </li>
                  <li class="nav-item">
                  <a class="nav-link" href="doctorlogin.php">Management</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="contactus.php">Contact us</a>
                </li>
                </ul>
                <img class="pic" src="menu.png">  
        </div>
    </nav>
    <div class="heading">
      <center><h2>COVID Hospital Management</h2></center>
    </div>
    <center>

    <div class="container">
      <div class="image" >
        
      </div>
      <div class="guidelines">
        <ul>
          <h3>COVID Guidelines</h3><br>
       <li> <h5>Get vaccinated as soon as you are eligible.</h5></li><br>
       <li> <h5>Wash your hands regularly with soap and water for at least 20 seconds.</h5></li><br>
       <li><h5>Follow local guidelines regarding mask-wearing requirements.</h5></li><br>
       <li><h5>Maintain physical distance (at least 6 feet or 2 meters) from individuals. </h5></li><br>
       <li><h5>Follow quarantine and isolation guidelines,</h5></li>
      </ul>
      </div>
    
    </div>
    </center>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>