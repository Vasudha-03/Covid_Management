<?php
include 'connect.php';

if (isset($_POST['submit'])) {
    $FIRSTNAME = $_POST['firstname'];
    $LASTNAME = $_POST['lastname'];
    $AGE = $_POST['age'];
    $ADHAR = $_POST['adhar'];
    $PHONENO = $_POST['phone'];
    $GENDER = $_POST['gender'];
    $DOSAGE = $_POST['dosage'];
    $DATES = $_POST['date'];
    $EMAIL = $_POST['email'];
    $ADDRESS = $_POST['address'];

    $sql = "SELECT * FROM vaccine WHERE FIRSTNAME=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $FIRSTNAME);
    $stmt->execute();

    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        ?>
        <script type="text/javascript">alert("Data already exists!");</script>
        <?php
    } else {
        // Template for SQL query
        $sql = "INSERT INTO vaccine (FIRSTNAME,LASTNAME,AGE,ADHAR,PHONENO,GENDER,DOSAGE,DATES,EMAIL,ADDRESS) VALUES (?,?,?,?,?,?,?, ?,?, ?)";
        // Preparing the statement
        $stmt = $conn->prepare($sql);
        // Bind all data with actual values from placeholder like ?
        $stmt->bind_param("ssssssssss", $FIRSTNAME, $LASTNAME, $AGE, $ADHAR, $PHONENO, $GENDER, $DOSAGE, $DATES, $EMAIL, $ADDRESS);
        $result = $stmt->execute();

        if ($result) {
            ?>
            <script type="text/javascript">
                alert("Data saved successfully!");
                window.location.replace("submited.php");
            </script>
            <?php
        } else {
            ?>
            <script type="text/javascript">alert("Error inserting data!");</script>
            <?php
        }
    }

    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Appointment</title>">

        <style>
	        body {
                margin: 0;
                padding: 0;
                font-family: Arial, sans-serif;
                color: #fff;
            }
            .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            #signup{
                background:#14076F ;
                height:50px ;
                width: 350px;
               margin-left: 8%;
               margin-right: 20%;
               align-items: center;
               justify-content: center;
               display:block;
               /*border-radius: 35%;*/
                font-size: 13px;
                border-radius: 25px;

            }
            .firm h1{
                position: relative;
                top: 7px;
            }
            .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
             .firm{
                position: center;
                width: 400px;
                height: 520px;
                margin: 5% auto;
                margin-top: 1px;
                background:transparent;
                text-align:center;
                color: white;
                background: white;
                /*border-radius: 5%;*/
                /*border: 1px solid black;*/
            }
            .firm h1{
                text-align: center;
            }
            .firm form{
                padding:0 40px;
            }
            form .txt_field{
                position: relative;
                border-bottom: 2px solid #adadad;
                margin: 30px 0;
            }
            .txt_field input{
                width: 100%;
                padding: 0 5px;
                height: 40px;
                font-size: 14px;
                border: none;
                background: none;
                outline: none;
                
            }
            .txt_field label{
                position: absolute;
                top: 50%;
                left: 5px;
                color:#14076F;
                transform: translateY(-50%);
                font-size: 16px;
                pointer-events: none;
                transition: 0.3s;

            }
           .txt_field span::before{
                content: '';
                position: absolute;
                top: 40px;
                left: 0;
                width: 0%;
                height: 2px;
                background:#14076F;
                transition: 0.3s;
            }
            .txt_field input:focus ~ label,
            .txt_field input:valid ~ label{
                top: -5px;
                color:#14076F;
            }
            .txt_field input:focus ~ span::before,
            .txt_field input:valid ~ span::before{
                width: 100%;
            }
            #text{
                color:#14076F ;
                position: relative;
                right: 31px;

            }
            #txt1{
                color:#14076F ;
                position: relative;
                right: 67px;

            }
              #text1{
                color:#14076F ;
                position: relative;
                right: 40px;

            }

            #texts{
                color:#14076F ;position: relative;
                bottom: 15px;
            }
            #txt{
                 color:#14076F ;
                position: relative;
                right: 15%;
            }
            #txts{
                 color:#14076F ;
                position: relative;
                right: 17%;
            }
           .cn{
                width: 100px;
                height: 40px;
                background: #14076F;
                border: none;
                position:center;
                font-size: 18px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
                color: #fff;
                text-decoration: none;
                transition: .3s
            }
            
            .cn:hover{
                background-color: #5B4FB3;
                color: #fff;
            }
             .genderclass{
                position: relative;
                left: 7%;
            }
            .record{
                color: black;
                position: relative;
                right: 28px;
            }
            .dateclass{
                position: relative;
                left: 28px;
            }
            .dose{
                position: relative;
                left: 40px;
            }
            center a{
                text-decoration: none;
                color: #fff;
            }
        </style>
    </head>
    <body>
        <div class="con">
            <nav>
                <img class="logo" src="APSCE_Logo.jpeg">
       
                <a href="home.php"><img class="pic" src="menu.png"></a>    
       
            </nav>
        </div>
	    <div class="firm">
            <div id="signup"><h1>Appointment For Vaccine</h1></div>
                <form method="post">
                    <div class="txt_field">
                        <input type="text" name="firstname"required>
                        <span></span>
                        <label>Enter your First Name</label>
                    </div>
                    <div class="txt_field">
                        <input type="text"  name="lastname" required>
                        <span></span>
                        <label>Enter your Last Name</label>
                    </div>
                    <div class="txt_field">
                        <input type="text" name="age" required>
                        <span></span>
                        <label>Enter Your Age</label>
                    </div>
                    <div class="txt_field">
                        <input type="tel" pattern="[0-9]{12}" maxlength="12" name="adhar"required>
                        <span></span>
                        <label>Enter Your Adhar Number</label>
                    </div>
                    <div class="txt_field">
                        <input type="tel" pattern="[0-9]{10}" maxlength="10" name="phone" required>
                        <span></span>
                        <label>Enter Your Phone Number</label>
                    </div>
                    <div>
                        <label id="txt">Select Your Gender</label>
                        <select name="gender" class="genderclass"required>
                            <option value=" ">Select</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="others">others</option>
                        </select>
                    </div><br><br>
                    <div>
                        <label id="txt1">Select Dosage</label>
                        <select name="dosage" class="dose"required>
                            <option value=" ">Select</option>
                            <option value="First">First</option>
                            <option value="Second">Second</option>
                        </select>
                    </div><br><br>
                    <div>
                        <span></span>
                        <label id="txts" class="date">Select Date</label>
                        <input type="date" class="dateclass" name="date"required>
                    </div>
                    <div class="txt_field">
                        <input type="email" name="email"required>
                        <span></span>
                        <label>Email</label>
                    </div>
                    <div class="text_field">
                        <span></span>
                        <label id="texts" >Enter Your Address</label>
                        <textarea name="address"required></textarea><br><br>
                    </div>
                    <center><button class="cn" name="submit">Submit</button></center><br>
                </form>
	    </div>
    </body>
</html>