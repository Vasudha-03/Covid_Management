<?php
include 'connect.php';

// Initialize variables
$username = '';
$userData = null;

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Get the username from the form
    $username = $_POST['username'];

    // Prepare and execute the SQL query to fetch user details for the given username
    $sql = "SELECT * FROM user_login WHERE USERNAME = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch data from the database
    $userData = $result->fetch_assoc();

    // Close the database connection
    $stmt->close();
    $conn->close();
}

// Set the initial value of the username input field
$initialUsername = $userData ? $userData['USERNAME'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #F8F8F8;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            
            .firm h1{
                position: relative;
                top: 7px;
            }
            .logo{
                height: 100%;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
        .container {
            width: 80%;
            margin: 20px auto;
        }

        h1 {
            color: #14076F;
        }

        p {
            color: #14076F;
            margin-bottom: 10px;
        }

        form {
            margin-top: 20px;
        }

        input {
            padding: 8px;
        }

        .submit-button {
            padding: 10px;
            background-color: #14076F;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .update-button {
            padding: 10px;
            background-color: #5B4FB3;
            color: #fff;
            text-decoration: none;
            border: none;
            cursor: pointer;
            display: inline-block;
        }

        .update-button:hover {
            background-color: #3C3279;
        }
    </style>
</head>
<body>
    <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <a href="Home.php"><img class="pic" src="menu.png"> </a> 
        </nav>
    </div>
    <div class="container">
        <h1>User Profile</h1>

        <form method="post">
            <label for="username">Enter User Name:</label>
            <input type="text" id="username" name="username" value="<?php echo $initialUsername; ?>" required>
            <button type="submit" name="submit" class="submit-button">Submit</button>
        </form>

        <?php
        // Display user profile if available
        if ($userData) {
            ?>
            <p><strong>Name:</strong> <?php echo $userData['USERNAME']; ?></p>
            <p><strong>Phoneno:</strong> <?php echo $userData['PHONE']; ?></p>
            <p><strong>Adhar no:</strong> <?php echo $userData['ADHAR']; ?></p>

            <!-- Add more details as needed -->

            <!-- Update button to link to the update page -->
            <a class="update-button" href="userupdate.php?NAME=<?php echo $userData['USERNAME']; ?>">Update</a>
            <?php
        } elseif ($username !== '') {
            // Handle the case where the user is not found
            echo "<p>User profile not found for the given name.</p>";
        }
        ?>
    </div>
</body>
</html>
