<?php
include 'connect.php';
session_start();

if(isset($_POST['submit']))
{
    $PASSWORD = $_POST['password'];
    $ID = $_POST['id'];
    
    $sql = "SELECT NAME, PASSWORD FROM doctor_login WHERE ID=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $ID);
    $stmt->execute();

    $stmt->bind_result($db_name, $db_password); /*storing username and password*/
    
    if($stmt->fetch()) {
        /*fetching the data*/
        if($PASSWORD == $db_password) {
            $_SESSION['ID'] = $db_name;
            header("location: doctorhome.php");
            exit(); // Add exit to stop execution after redirect
        } else {
            ?>
            <script type="text/javascript">alert("Incorrect password");</script>
            <?php
        }
    } else {
        ?>
        <script type="text/javascript">alert("Incorrect username");</script>
        <?php
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Login</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            box-sizing: border-box;
            background-color: #F8F8F8;
        }

        .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            #signup{
                background:#14076F ;
                height:50px ;
               margin-left: 20%;
               margin-right: 20%;
               align-items: center;
               justify-content: center;
               display:block;
               /*border-radius: 35%;*/
                font-size: 13px;
                border-radius: 25px;

            }
            .firm h1{
                position: relative;
                top: 7px;
            }
        nav {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

       .logo{
                height: 60px;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
           

        .firm {
            width: 300px;
            margin: 1% auto;
            background: transparent;
            text-align: center;
            color: #14076F;
            
        }

        #signup {
            background: #14076F;
            height: 50px;
            width: 150px;
            border-radius: 25px;
            font-size: 15px;
            color: white;
            margin-left: 25%;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;

        }
        #signup h2{
            position:relative;
            top: 12px;
        }

        label {
            display: block;
            text-align: left;
            margin-top: 10px;
            color: #14076F;
        }

        input, select {
            width: 100%;
            padding: 6px;
            margin-top: 3px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn{
                width: 100px;
                height: 40px;
                background: #14076F;
                border: none;
                position:center;
                font-size: 18px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
                color: #fff;
                text-decoration: none;
                transition: .3s
            }
            
            .btn:hover{
                background-color: #5B4FB3;
                color: #fff;
            }

        p {
            color: black;
            margin-top: 20px;
        }
        p a{
            color: black;
            text-decoration: none;
        }
        .sn{
            text-decoration: none;
            color: #14076F;
        }
    </style>
</head>
<body>
    <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <a href="home.php"><img class="pic" src="menu.png"></a>
        </nav>
    </div>
    <div class="firm">
        <div id="signup"><center><h2 style="text-align: center;">Sign In</h2></center></div>
        <form method="post" name="userlogin" id="loginform">
            <!-- <h1 >Doctor Login Form</h1> -->
                <label>Name</label><br>
                <input type="id" name="name" required><br><br>
                <label for="id">ID</label>
                <input type="text"  name="id" required><br><br>
                <label>Password</label><br>
                <input type="text" name="password" required><br><br>
                <button class="btn" name="submit">Login</button><br><br>
                <a class="sn" href="forgotdoctor.php">Forgot Password</a>
        </form>
        <p> Already a Member? <a href="DoctorRegistration.php">Sign In</a></p>
    </div>
</body>
</html>
