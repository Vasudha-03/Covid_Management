<?php
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    $appointment_id = $_POST['appointment_id'];
    $appointment_type = $_POST['appointment_type'];
    $action = $_POST['action'];

    // Define status based on action
    $status = ($action === 'accept') ? 'accepted' : 'rejected';

    // Update appointment status in the database based on appointment type
    switch ($appointment_type) {
        case 'test':
            $table = 'test';
            break;
        case 'vaccine':
            $table = 'vaccine';
            break;
        case 'consult':
            $table = 'consult';
            break;
        default:
            // Handle unknown appointment type
            break;
    }

    if (isset($table)) {
        $sql = "UPDATE $table SET status = ? WHERE ADHAR = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $status, $appointment_id);
        $stmt->execute();
        $stmt->close();
    }
}

// Fetch data from the "test" table
$sqlTest = "SELECT * FROM test1";
$resultTest = $conn->query($sqlTest);
$dataTest = $resultTest->fetch_all(MYSQLI_ASSOC);

// Fetch data from the "vaccine" table
$sqlVaccine = "SELECT * FROM vaccine";
$resultVaccine = $conn->query($sqlVaccine);
$dataVaccine = $resultVaccine->fetch_all(MYSQLI_ASSOC);

$sqlconsult = "SELECT * FROM con";
$resultconsult = $conn->query($sqlconsult);
$dataconsult = $resultconsult->fetch_all(MYSQLI_ASSOC);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Data</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #F8F8F8;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .con {
            display: block;
            align-items: left;
            height: 9%;
            width: 100%;
            justify-content: center;
            background-color: #14076F;
        }

        .firm h1 {
            position: relative;
            top: 7px;
        }

        .logo {
            height: 100%;
            width: 5%;
            margin-left: 2%;
        }

        .pic {
            margin-top: 10px;
            height: 30px;
            width: 50px;
            float: right;
            margin-right: 4px;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            margin: 20px auto;
        }

        .card {
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 10px;
            margin: 10px;
            padding: 10px;
            background-color: #fff;
        }

        button {
            width: 80px;
            height: 30px;
            background: #14076F;
            border: none;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
            transition: .4s ease;
            color: #fff;
            text-decoration: none;
        }

        button:hover {
            background: #5B4FB3;
        }

        a {
            text-decoration: none;
            color: #fff;
        }

        a:hover {
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="con">
            <nav>
                <img class="logo" src="APSCE_Logo.jpeg">
                <a href="home.php"><img class="pic" src="menu.png"></a>
            </nav>
    </div>
    <div class="container">
        <!-- Display data from the "test" table -->
        <?php foreach ($dataTest as $row) : ?>
            <div class="card">
                <h2>Appointment for Test</h2>
                <!-- Display appointment details -->
                <p>First Name: <?php echo $row['FIRSTNAME']; ?></p>
                <p>Last Name: <?php echo $row['LASTNAME']; ?></p>
                    <p>Age: <?php echo $row['AGE']; ?></p>
                    <p>Phone number: <?php echo $row['PHONENO']; ?></p>
                    <p>Gender: <?php echo $row['GENDER']; ?></p>
                    <p>Bloodgroup: <?php echo $row['BLOODGROUP']; ?></p>
                    <p>Email: <?php echo $row['EMAIL']; ?></p>
                    <p>Address: <?php echo $row['ADDRESS']; ?></p>
                    <p>Adhar: <?php echo $row['ADHAR']; ?></p>
                <form action="accept_reject.php" method="post">
                    <input type="hidden" name="appointment_id" value="<?php echo $row['ADHAR']; ?>">
                    <input type="hidden" name="appointment_type" value="test">
                    <button type="submit" name="action" value="accept">Accept</button>
                    <button type="submit" name="action" value="reject">Reject</button>
                </form>
            </div>
        <?php endforeach; ?>

        <!-- Display data from the "vaccine" table -->
        <?php foreach ($dataVaccine as $row) : ?>
            <div class="card">
                <h2>Appointment for Vaccine</h2>
                <!-- Display appointment details -->
                <p>First Name: <?php echo $row['FIRSTNAME']; ?></p>
                <p>Last Name: <?php echo $row['LASTNAME']; ?></p>
                    <p>Age: <?php echo $row['AGE']; ?></p>
                    <p>Adhar: <?php echo $row['ADHAR']; ?></p>
                    <p>Phone number: <?php echo $row['PHONENO']; ?></p>
                    <p>Gender: <?php echo $row['GENDER']; ?></p>
                    <p>Dosage: <?php echo $row['DOSAGE']; ?></p>
                    <p>Date: <?php echo $row['DATES']; ?></p>
                    <p>Email: <?php echo $row['EMAIL']; ?></p>
                    <p>Address: <?php echo $row['ADDRESS']; ?></p>
                <form action="accept_reject.php" method="post">
                    <input type="hidden" name="appointment_id" value="<?php echo $row['ADHAR']; ?>">
                    <input type="hidden" name="appointment_type" value="vaccine">
                    <button type="submit" name="action" value="accept">Accept</button>
                    <button type="submit" name="action" value="reject">Reject</button>
                </form>
            </div>
        <?php endforeach; ?>

        <!-- Display data from the "consult" table -->
        <?php foreach ($dataconsult as $row) : ?>
            <div class="card">
                <h2>Appointment for Consult</h2>
                <!-- Display appointment details -->
                <p>First Name: <?php echo $row['FIRSTNAME']; ?></p>
                <p>Last Name: <?php echo $row['LASTNAME']; ?></p>
                <p>Age: <?php echo $row['AGE']; ?></p>
                    <p>Adhar: <?php echo $row['ADHAR']; ?></p>
                    <p>Phone number: <?php echo $row['PHONENO']; ?></p>
                    <p>Gender: <?php echo $row['GENDER']; ?></p>
                    <p>Visit: <?php echo $row['VISIT']; ?></p>
                    <p>Email: <?php echo $row['EMAIL']; ?></p>
                    <p>Address: <?php echo $row['ADDRESS']; ?></p>
                <form action="accept_reject.php" method="post">
                    <input type="hidden" name="appointment_id" value="<?php echo $row['ADHAR']; ?>">
                    <input type="hidden" name="appointment_type" value="consult">
                    <button type="submit" name="action" value="accept">Accept</button>
                    <button type="submit" name="action" value="reject">Reject</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
