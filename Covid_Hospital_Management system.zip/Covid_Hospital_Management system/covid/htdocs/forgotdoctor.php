<?php
include 'connect.php';
if(isset($_POST['submit'])){

    $PASSWORD=$_POST['password'];
    $CONFIRMPASSWORD=$_POST['confirmpassword'];
    $NAME=$_POST['name'];
   
 if ($PASSWORD !== $CONFIRMPASSWORD) {
        ?>
        <script type="text/javascript">alert("Password and Confirm Password not matched");</script>

        <?php
    }
        else{
            $sql = "UPDATE doctor_login SET PASSWORD=?,CONFIRMPASSWORD=? WHERE NAME=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $PASSWORD,$CONFIRMPASSWORD,$NAME);

            $result=$stmt->execute();

if($result){
    ?> <script> alert("Password changed Successfully & Updated in the Database."); 
            
                    window.location.href = "doctorlogin.php";
</script>
  <?php
  }else{ ?>
    <script> alert("The Update Operation was Unsuccessful"); </script>
  <?php
  }

}
}

?> 


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reseting Password</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            box-sizing: border-box;
            background-color: #F8F8F8;
        }

        .con{
                display: block;
                align-items: left;
                height: 9%;
                width: 100%;
                justify-content: center;
                background-color:#14076F;

            }
            #signup{
                color:#14076F ;
            }
            .firm h1{
                position: relative;
                top: 7px;
            }
        nav {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

       .logo{
                height: 60px;
                width: 5%;
                margin-left: 2%;
            }
            .pic{
                margin-top: 10px;
                height: 30px;
                width:50px;
                float: right;
                margin-right: 4px;
            }
           

        .firm {
            width: 300px;
            margin: 1% auto;
            background: transparent;
            text-align: center;
            color: #14076F;
            
        }


        label {
            display: block;
            text-align: left;
            margin-top: 10px;
            color: #14076F;
        }

        input, select {
            width: 100%;
            padding: 6px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn{
                width: 100px;
                height: 40px;
                background: #14076F;
                border: none;
                position:center;
                font-size: 18px;
                border-radius: 20px;
                cursor: pointer;
                transition: .4s ease;
                color: #fff;
                text-decoration: none;
                transition: .3s
            }
            
            .btn:hover{
                background-color: #5B4FB3;
                color: #fff;
            }

        p {
            color: #14076F;
            margin-top: 20px;
        }
        p a{
            text-decoration: none;
            color: #14076F ;
        }
     
    </style>
</head>
<body>
    <div class="con">
        <nav>
            <img class="logo" src="APSCE_Logo.jpeg">
            <a href="home.php"><img class="pic" src="menu.png"></a>
        </nav>
    </div>
    <div class="firm">
        <div id="signup"><center><h2 style="text-align: center;">Forgot Password</h2></center></div>
        <form method="post" name="userlogin" id="loginform">
                <label>Name</label><br>
                <input type="id" name="name" required><br><br>
                <label>Password</label><br>
                <input type="text" name="password" required><br><br>
                <label>ConfirmPassword</label><br>
                <input type="text" name="confirmpassword" required><br><br>
                <button class="btn" name="submit">Submit</button><br><br>
        </form>
    </div>
</body>
</html>
